package com.smart.smartcontactmanager.models;



import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "categories")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name = "category_name")
    private  String categoryName;
    @Column( length = 5000)
    private  String description;

    @Column(name = "image_url")
    private String imageUrl;
    @OneToMany(cascade = CascadeType.MERGE,fetch = FetchType.LAZY,mappedBy = "category")
    private List<Product>products =new ArrayList<>();

    public Category() {

    }



  /*  public List<Product> getProducts(Category category) {
        return category.products;
    }
*/

    public Integer getId() {
        return id;
    }

    public List<Product> getProducts() {
        return products;
    }

    /* public List<Product> getProducts() {
            return products;
        }
    */
    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId(Category category) {
        return category.id;
    }


    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return categoryName;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", categoryName='" + categoryName + '\'' +
                ", description='" + description + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }
}
