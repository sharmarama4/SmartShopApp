package com.smart.smartcontactmanager.controller;


import com.smart.smartcontactmanager.models.Product;
import com.smart.smartcontactmanager.models.User;

import com.smart.smartcontactmanager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;



import java.security.Principal;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @ModelAttribute
    public void addCommonData(Model model, Principal principal) {
        String userName = principal.getName();
        //get the user using username(Email)
        System.out.println("USERNAME :" + userName);
        User user = userService.getUserByUserName(userName);
        model.addAttribute("user", user);
        System.out.println("USER " + user);
    }

    @RequestMapping("/index")

    public String dashboard(Model model, Principal principal) {
        model.addAttribute("title", "My Home page");
      /*  String userName = principal.getName();

        System.out.println("USERNAME: " + userName);
        User user = userService.getUserByUserName(userName);
        if (user != null) {
            model.addAttribute("user", user);
            System.out.println("YAY");
        } else {
            model.addAttribute("user", new User());
            System.out.println("Bag of d**ks");
            System.out.println("USER " + user);
        }
        model.addAttribute("user", user);
        System.out.println("USER " + user);*/
        return "contact/user_dashboard";
    }

   /* @GetMapping("/add-contact")
    public String openAddContactForm(Model model) {
        model.addAttribute("title", "Add_contact ");//to get the title
        model.addAttribute("contact", new Contact());
        return "contact/add_contact_form";
    }*/

    @GetMapping("/add-user")
    public String openAddUserForm(Model model) {
        model.addAttribute("title", "Add_User ");//to get the title
        model.addAttribute("user", new User());
        return "user/add_user_form";
    }

   /* @GetMapping("/add-product")
    public String openAddProductForm(Model model) {
        model.addAttribute("title", "Add_product ");//to get the title
        model.addAttribute("product", new Product());
        return "product/add_product";
    }*/
    //processing add contact form
/*
@PostMapping("/process-contact")
    public String processContact(@ModelAttribute Contact contact,Principal principal){
        String name=principal.getName();
       User user= this.userService.getUserByUserName(name);
      contact.setUser(user);//this both line are important
       user.getContacts().add(contact);
    System.out.println("Data "+contact);
    this.userService.save(user);
    System.out.println("added to database");
    return "contact/add_contact_form";
}
}*/
}